﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigLetter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("H       H");
            Console.WriteLine("H       H");
            Console.WriteLine("H       H");
            Console.WriteLine("HHHHHHHHH");
            Console.WriteLine("H       H");
            Console.WriteLine("H       H");
            Console.WriteLine("H       H\n");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
