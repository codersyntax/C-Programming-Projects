﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WineGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("XXXXXXXXXXXXXX");
            Console.WriteLine(" X          X ");
            Console.WriteLine("  X        X  ");
            Console.WriteLine("   XXXXXXXX   ");
            Console.WriteLine("      XX      ");
            Console.WriteLine("      XX      ");
            Console.WriteLine("    XXXXXX    \n");
            Console.WriteLine("TADDDAAAAA WINEGLASS!");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
