﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BurmaShave
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("WITHIN THIS VALE");
            Console.WriteLine("OF TOIL");
            Console.WriteLine("AND SIN");
            Console.WriteLine("YOUR HEAD GROWS BALD");
            Console.WriteLine("BUT NOT YOUR CHIN\n");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();

        }
    }
}
